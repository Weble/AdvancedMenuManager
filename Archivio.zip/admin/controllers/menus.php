<?php
/**
 * Menu Controller
 */

class AdvancedmenusControllerMenus extends FOFController {
	
}