<?php
// Protect from unauthorized access
defined('_JEXEC') or die();

class AdvancedmenusToolbar extends FOFToolbar
{
	
}
